package com.cg.crowdsourcingproject.mqtt;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Random;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import java.util.Date;
import java.util.Timer;


  public class MqttConnect implements MqttCallback{
	

	  MqttClient myClient;
		MqttConnectOptions connOpt;

		static final String BROKER_URL = "tcp://192.168.1.2";
		//static final String M2MIO_DOMAIN = "<Insert m2m.io domain here>";
		//static final String M2MIO_STUFF = "things";
		static final String M2MIO_THING = "PredixLab_MQmgr";
		static final String M2MIO_USERNAME = "Predix_LAB";
		//static final String M2MIO_PASSWORD_MD5 = "8ac7594a239be782031a679e0f79dad3";
              static final String M2MIO_PASSWORD_MD5 = "poiuy123";

		// the following two flags control whether this example is a publisher, a subscriber or both
		static final Boolean subscriber = true;
		static final Boolean publisher = true;

		/**
		 * 
		 * connectionLost
		 * This callback is invoked upon losing the MQTT connection.
		 * 
		 */
		@Override
		public void connectionLost(Throwable t) {
			System.out.println("Connection lost!");
			// code to reconnect to the broker would go here if desired
		}

		/**
		 * 
		 * deliveryComplete
		 * This callback is invoked when a message published by this client
		 * is successfully received by the broker.
		 * 
		 */
		@Override
		public void deliveryComplete(IMqttDeliveryToken token) {
			//System.out.println("Pub complete" + new String(token.getMessage().getPayload()));
		}

		/**
		 * 
		 * messageArrived
		 * This callback is invoked when a message is received on a subscribed topic.
		 * 
		 */
		@Override
		public void messageArrived(String topic, MqttMessage message) throws Exception {
			System.out.println("-------------------------------------------------");
		//	System.out.println("| Topic:" + topic.getName());
			System.out.println("| Message: " + new String(message.getPayload()));
			System.out.println("-------------------------------------------------");
		}
		
		
		public void messageArrived(MqttTopic topic, MqttMessage message) throws Exception {
			System.out.println("-------------------------------------------------");
			System.out.println("| Topic:" + topic.getName());
			System.out.println("| Message: " + new String(message.getPayload()));
			System.out.println("-------------------------------------------------");
		}
		

		/**
		 * 
		 * MAIN
		 * 
		 */


		 public ArrayList<String> topicNames(){
	   ArrayList<String> list=new ArrayList<String>();
		Random rand = new Random();
                int a = rand.nextInt(20) + 1;
                int b = rand.nextInt(20) + 1;
                int c = rand.nextInt(20) + 1;
                int d = rand.nextInt(20) + 1;
                int e = rand.nextInt(20) + 1;
                int f = rand.nextInt(20) + 1;
                int g = rand.nextInt(20) + 1;
                int h = rand.nextInt(20) + 1;
                int i = rand.nextInt(20) + 1;


		 Date date= new Date();
		//String output="Hos1_Doc"+"|"+rand.nextInt(20) + 1+"|"+timestamp;
		//for(int i=1;i<=3;i++){
			
			//String output1="Hos"+i+"_Doc"+"|"+a+"|"+date.getTime();
                        String output1="Hos1_Doc"+"|"+a+"|"+date.getTime();
                     	String output2="Hos1_Pat"+"|"+b+"|"+date.getTime();
                     	String output3="Hos1_AWT"+"|"+c+"|"+date.getTime();	
                        String output4="Hos2_Doc"+"|"+d+"|"+date.getTime();
                        String output5="Hos2_Pat"+"|"+e+"|"+date.getTime();
                        String output6="Hos2_AWT"+"|"+f+"|"+date.getTime();
                        String output7="Hos3_Doc"+"|"+g+"|"+date.getTime();
                        String output8="Hos3_Pat"+"|"+h+"|"+date.getTime();
                        String output9="Hos3_AWT"+"|"+i+"|"+date.getTime();      		
			list.add(output1);
			list.add(output2);
			list.add(output3);
                        list.add(output4);
                        list.add(output5);
                        list.add(output6);
                        list.add(output7);
                        list.add(output8);
                        list.add(output9); 
						
		//}
	   
	   return list;
   }
		public static void main(String[] args) throws InterruptedException{
			//Timer time = new Timer();
			MqttConnect smc = new MqttConnect();
			for(;;){
                        Thread.sleep(1000);
			smc.runClient();
			}
               
		}
		
		/**
		 * 
		 * runClient
		 * The main functionality of this simple example.
		 * Create a MQTT client, connect to broker, pub/sub, disconnect.
		 * 
		 */
		public void runClient() {
			// setup MQTT Client
			String clientID = M2MIO_THING;
			connOpt = new MqttConnectOptions();
			
			connOpt.setCleanSession(true);
			connOpt.setKeepAliveInterval(30);
			connOpt.setUserName(M2MIO_USERNAME);
			connOpt.setPassword(M2MIO_PASSWORD_MD5.toCharArray());
			
			// Connect to Broker
			try {
				myClient = new MqttClient(BROKER_URL, clientID);
				//myClient=new MqttClient(serverURI, clientId)
				myClient.setCallback(this);
				myClient.connect(connOpt);
			} catch (MqttException e) {
				e.printStackTrace();
				System.exit(-1);
			}
			
			System.out.println("Connected to " + BROKER_URL);

			// setup topic
			// topics on m2m.io are in the form <domain>/<stuff>/<thing>

			ArrayList<String> topicNamesList=new ArrayList<String>();
		topicNamesList=topicNames();
		for (String msg : topicNamesList) {
			
			System.out.println("printing topic"+msg);
		
			//String myTopic = M2MIO_DOMAIN + "/" + M2MIO_STUFF + "/" + M2MIO_THING;
			String myTopic = "HospitalQueue";
			MqttTopic topic = myClient.getTopic(myTopic);

			// subscribe to topic if subscriber
			if (subscriber) {
				try {
					int subQoS = 0;
					myClient.subscribe(myTopic, subQoS);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			// publish messages if publisher
			if (publisher) {
				//for (int i=1; i<=10; i++) {
			   		//String pubMsg = "{\"Hello World\":" + i + "}";
			   		String pubMsg = msg;
					int pubQoS = 0;
					MqttMessage message = new MqttMessage(pubMsg.getBytes());
			    	message.setQos(pubQoS);
			    	message.setRetained(false);

			    	// Publish the message
			    	System.out.println("Publishing to topic \"" + topic + "\" qos " + pubQoS);
			    	MqttDeliveryToken token = null;
			    	try {
			    		// publish message to broker
						token = topic.publish(message);
					System.out.println("dfdgfg"+token);

				    	// Wait until the message has been delivered to the broker
						token.waitForCompletion();
						Thread.sleep(100);
					} catch (Throwable e) {
						e.printStackTrace();
					}
				//}			
			}
}
			
			// disconnect
			try {
				// wait to ensure subscribed messages are delivered
				if (subscriber) {
					Thread.sleep(5000);
				}
				myClient.disconnect();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	

		
}

